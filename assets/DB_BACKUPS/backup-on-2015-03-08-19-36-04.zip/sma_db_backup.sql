#
# TABLE STRUCTURE FOR: billers
#

DROP TABLE IF EXISTS billers;

CREATE TABLE `billers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `invoice_footer` varchar(1000) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO billers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `logo`, `invoice_footer`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'Mian Saleem', 'Tecdiary IT Solutions', 'Address', 'City', 'Sate', '0000', 'Malaysia', '012345678', 'saleem@tecdairy.com', 'logo.png', '', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: calendar
#

DROP TABLE IF EXISTS calendar;

CREATE TABLE `calendar` (
  `date` date NOT NULL,
  `data` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: categories
#

DROP TABLE IF EXISTS categories;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO categories (`id`, `code`, `name`) VALUES (1, 'C1', 'Category 1');


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS comment;

CREATE TABLE `comment` (
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO comment (`comment`) VALUES ('&lt;h4&gt;Thank you for Purchasing Stock Manager Advance 2.3 with POS Module &lt;/h4&gt;\r\n&lt;p&gt;\r\n              This is latest the latest release of Stock Manager Advance.\r\n&lt;/p&gt;');


#
# TABLE STRUCTURE FOR: customer_balance
#

DROP TABLE IF EXISTS customer_balance;

CREATE TABLE `customer_balance` (
  `customer_balance_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `customer_balance` decimal(10,2) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_balance_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (1, 2, '0.00', '2015-03-05 05:13:34');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (2, 4, '1500.00', '0000-00-00 00:00:00');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (3, 1, '10000.00', '2015-03-05 05:34:38');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (4, 8, '123456.00', '2015-03-05 05:52:16');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (5, 1, '5000.00', '2015-03-05 05:52:49');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (6, 1, '3736.00', '2015-03-05 10:01:56');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (7, 2, '-600.00', '2015-03-05 10:14:09');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (8, 1, '2372.00', '2015-03-05 10:16:40');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (9, 1, '1508.00', '2015-03-05 10:18:12');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (10, 1, '-1364.00', '2015-03-05 10:25:53');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (11, 1, '-3208.00', '2015-03-05 12:27:59');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (12, 1, '-5052.00', '2015-03-08 09:57:03');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (13, 1, '-4796.00', '2015-03-08 10:00:31');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (14, 1, '-6640.00', '2015-03-08 10:33:03');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (15, 1, '-8484.00', '2015-03-08 12:06:44');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (16, 1, '-10328.00', '2015-03-08 12:08:22');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (17, 1, '-11428.00', '2015-03-08 12:10:39');
INSERT INTO customer_balance (`customer_balance_id`, `customer_id`, `customer_balance`, `date`) VALUES (18, 2, '-1964.00', '2015-03-08 12:32:16');


#
# TABLE STRUCTURE FOR: customer_discount
#

DROP TABLE IF EXISTS customer_discount;

CREATE TABLE `customer_discount` (
  `customer_discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `discount_type` varchar(200) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`customer_discount_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO customer_discount (`customer_discount_id`, `customer_id`, `product_id`, `discount_type`, `discount_amount`) VALUES (12, 1, 12, '2', '500.00');
INSERT INTO customer_discount (`customer_discount_id`, `customer_id`, `product_id`, `discount_type`, `discount_amount`) VALUES (11, 2, 14, '2', '500.00');
INSERT INTO customer_discount (`customer_discount_id`, `customer_id`, `product_id`, `discount_type`, `discount_amount`) VALUES (8, 2, 11, '2', '500.00');
INSERT INTO customer_discount (`customer_discount_id`, `customer_id`, `product_id`, `discount_type`, `discount_amount`) VALUES (13, 2, 12, '2', '1235.00');


#
# TABLE STRUCTURE FOR: customers
#

DROP TABLE IF EXISTS customers;

CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'Test Customer', 'Customer Company Name', 'Customer Address', 'Petaling Jaya', 'Selangor', '46000', 'Malaysia', '0123456789', 'customer@tecdiary.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (2, 'saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'abu_salea1h@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (3, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'abu_salea1h@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (4, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '2000002313', 'abu_salea1h@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (5, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'sadf@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (6, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'abu_salea1h2@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (7, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'abu_saleah@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (8, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'abu_salea55@yahoo.com', '', '', '', '', '', '');
INSERT INTO customers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (9, 'abu saleah', 'Service On', 'Mirpur', 'Dhaka', 'Dhaka', '1207', 'United Kingdom', '01722702590', 'abu_salea@yahoo.com', '', '', '', '', '', '');


#
# TABLE STRUCTURE FOR: damage_products
#

DROP TABLE IF EXISTS damage_products;

CREATE TABLE `damage_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: date_format
#

DROP TABLE IF EXISTS date_format;

CREATE TABLE `date_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `js` varchar(20) NOT NULL,
  `php` varchar(20) NOT NULL,
  `sql` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (1, 'mm-dd-yyyy', 'm-d-Y', '%m-%d-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (2, 'mm/dd/yyyy', 'm/d/Y', '%m/%d/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (3, 'mm.dd.yyyy', 'm.d.Y', '%m.%d.%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (4, 'dd-mm-yyyy', 'd-m-Y', '%d-%m-%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (5, 'dd/mm/yyyy', 'd/m/Y', '%d/%m/%Y');
INSERT INTO date_format (`id`, `js`, `php`, `sql`) VALUES (6, 'dd.mm.yyyy', 'd.m.Y', '%d.%m.%Y');


#
# TABLE STRUCTURE FOR: deliveries
#

DROP TABLE IF EXISTS deliveries;

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` varchar(10) NOT NULL,
  `reference_no` varchar(55) NOT NULL,
  `customer` varchar(55) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: discounts
#

DROP TABLE IF EXISTS discounts;

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `discount` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (1, 'No Discount', '0.00', '2');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (2, '2.5 Percent', '2.50', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (3, '5 Percent', '5.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (4, '10 Percent', '10.00', '1');
INSERT INTO discounts (`id`, `name`, `discount`, `type`) VALUES (5, 'Fixed', '200.00', '2');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS groups;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO groups (`id`, `name`, `description`) VALUES (1, 'owner', 'Owner');
INSERT INTO groups (`id`, `name`, `description`) VALUES (2, 'admin', 'Administrator');
INSERT INTO groups (`id`, `name`, `description`) VALUES (3, 'purchaser', 'Purchasing Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (4, 'salesman', 'Sales Staff');
INSERT INTO groups (`id`, `name`, `description`) VALUES (5, 'viewer', 'View Only User');


#
# TABLE STRUCTURE FOR: invoice_types
#

DROP TABLE IF EXISTS invoice_types;

CREATE TABLE `invoice_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `type` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS login_attempts;

CREATE TABLE `login_attempts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: pos_settings
#

DROP TABLE IF EXISTS pos_settings;

CREATE TABLE `pos_settings` (
  `pos_id` int(1) NOT NULL,
  `cat_limit` int(11) NOT NULL,
  `pro_limit` int(11) NOT NULL,
  `default_category` int(11) NOT NULL,
  `default_customer` int(11) NOT NULL,
  `default_biller` int(11) NOT NULL,
  `display_time` varchar(3) NOT NULL DEFAULT 'yes',
  `cf_title1` varchar(255) DEFAULT NULL,
  `cf_title2` varchar(255) DEFAULT NULL,
  `cf_value1` varchar(255) DEFAULT NULL,
  `cf_value2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO pos_settings (`pos_id`, `cat_limit`, `pro_limit`, `default_category`, `default_customer`, `default_biller`, `display_time`, `cf_title1`, `cf_title2`, `cf_value1`, `cf_value2`) VALUES (1, 22, 30, 1, 1, 1, 'yes', '', '', '', '');


#
# TABLE STRUCTURE FOR: products
#

DROP TABLE IF EXISTS products;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` char(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `weight` varchar(50) NOT NULL,
  `size` varchar(55) NOT NULL,
  `cost` decimal(25,2) DEFAULT NULL,
  `price` decimal(25,2) NOT NULL,
  `alert_quantity` int(11) NOT NULL DEFAULT '20',
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `cf1` varchar(255) DEFAULT NULL,
  `cf2` varchar(255) DEFAULT NULL,
  `cf3` varchar(255) DEFAULT NULL,
  `cf4` varchar(255) DEFAULT NULL,
  `cf5` varchar(255) DEFAULT NULL,
  `cf6` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `available_quantity` int(11) NOT NULL,
  `tax_rate` int(11) DEFAULT NULL,
  `track_quantity` tinyint(4) DEFAULT '1',
  `details` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `category_id` (`category_id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `category_id_2` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO products (`id`, `code`, `name`, `unit`, `weight`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `available_quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (11, '11', 'Fish', '50', '10', '10', '1000.00', '1100.00', 5, 'no_image.jpg', 1, 0, '', '', '', '', '', '', -70, -20, 1, 1, '');
INSERT INTO products (`id`, `code`, `name`, `unit`, `weight`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `available_quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (12, '22', 'Meat', '100', '10', '10', '1000.00', '1100.00', 10, 'no_image.jpg', 1, 0, '', '', '', '', '', '', -61, 39, 2, 1, '');
INSERT INTO products (`id`, `code`, `name`, `unit`, `weight`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `available_quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (13, '33', 'Sweet', '70', '5', '', '1000.00', '1100.00', 5, 'no_image.jpg', 1, 0, '', '', '', '', '', '', -19, 51, 2, 1, '');
INSERT INTO products (`id`, `code`, `name`, `unit`, `weight`, `size`, `cost`, `price`, `alert_quantity`, `image`, `category_id`, `subcategory_id`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`, `quantity`, `available_quantity`, `tax_rate`, `track_quantity`, `details`) VALUES (14, '66', 'Vege', '50', '', '', '100.00', '120.00', 3, 'login_logo.png', 1, 0, '', '', '', '', '', '', -3, 47, 1, 1, '');


#
# TABLE STRUCTURE FOR: purchase_items
#

DROP TABLE IF EXISTS purchase_items;

CREATE TABLE `purchase_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `tax_amount` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(255) DEFAULT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: purchases
#

DROP TABLE IF EXISTS purchases;

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) NOT NULL,
  `total` decimal(25,2) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT '0.00',
  `inv_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quote_items
#

DROP TABLE IF EXISTS quote_items;

CREATE TABLE `quote_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quote_id` (`quote_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotes
#

DROP TABLE IF EXISTS quotes;

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: sale_items
#

DROP TABLE IF EXISTS sale_items;

CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (1, 1, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (2, 2, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (3, 3, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (4, 4, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (5, 4, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (6, 5, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (7, 5, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (8, 6, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (9, 7, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (10, 7, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (11, 8, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (12, 8, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (13, 9, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (14, 9, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (15, 9, 2, '90789', 'Lal Shak', '12', 2, '24.00%', 1, '20.00', '20.00', '4.80', '', '0.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (16, 10, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (17, 10, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (18, 10, 2, '90789', 'Lal Shak', '12', 2, '24.00%', 1, '20.00', '20.00', '4.80', '', '0.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (19, 11, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (20, 11, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (21, 12, 4, '16', 'sdfsaf', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (22, 12, 4, '16', 'sdfsaf', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (23, 12, 4, '16', 'sdfsaf', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (24, 13, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (25, 13, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (26, 13, 2, '90789', 'Lal Shak', '12', 2, '24.00%', 1, '20.00', '20.00', '4.80', '', '0.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (27, 14, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (28, 14, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (29, 15, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (30, 15, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (31, 16, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (32, 16, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (33, 17, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (34, 17, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (35, 18, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (36, 18, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (37, 19, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (38, 19, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (39, 20, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (40, 20, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (41, 21, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (42, 21, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (43, 21, 2, '90789', 'Lal Shak', '12', 2, '24.00%', 1, '20.00', '20.00', '4.80', '', '0.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (44, 21, 4, '16', 'sdfsaf', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (45, 22, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (46, 22, 5, '17', 'monitor', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (47, 23, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (48, 23, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (49, 23, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (50, 24, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (51, 24, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (52, 25, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (53, 25, 2, '90789', 'Lal Shak', '12', 2, '24.00%', 1, '20.00', '20.00', '4.80', '', '0.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (54, 26, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (55, 26, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (56, 27, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (57, 27, 5, '17', 'monitor', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (58, 28, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (59, 28, 5, '17', 'monitor', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (60, 29, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (61, 29, 5, '17', 'monitor', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (62, 29, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (63, 29, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (64, 30, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (65, 30, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (66, 31, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '', '125.00', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (67, 31, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (68, 32, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (69, 33, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (70, 33, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (71, 39, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (72, 39, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (73, 40, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (74, 40, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (75, 41, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (76, 41, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (77, 42, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (78, 42, 1, '11', 'Keyboard', '5', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (79, 43, 1, '11', 'Keyboard', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (80, 43, 1, '11', 'Keyboard', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (81, 44, 7, '222', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (82, 45, 8, '333', 'Meat', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (83, 46, 1, '11', 'Keyboard', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (84, 46, 1, '11', 'Keyboard', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (85, 47, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (86, 47, 10, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (87, 48, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (88, 48, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (89, 48, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (90, 48, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (91, 48, 10, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (92, 49, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (93, 49, 10, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (94, 49, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (95, 49, 10, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (96, 51, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (97, 51, 9, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (98, 52, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (99, 53, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (100, 54, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (101, 54, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (102, 54, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (103, 54, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (104, 55, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (105, 55, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (106, 55, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (107, 55, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (108, 55, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (109, 56, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (110, 56, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (111, 56, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (112, 57, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (113, 57, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (114, 58, 13, '33', 'Sweet', '80', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (115, 58, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (116, 59, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (117, 59, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (118, 60, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (119, 60, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (120, 61, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (121, 61, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (122, 62, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (123, 62, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (124, 63, 13, '33', 'Sweet', '80', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (125, 63, 13, '33', 'Sweet', '80', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (126, 64, 13, '33', 'Sweet', '80', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (127, 64, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (128, 65, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (129, 65, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (130, 66, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (131, 66, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (132, 67, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (133, 67, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (134, 68, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (135, 68, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (136, 69, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (137, 69, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (138, 70, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (139, 70, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (140, 71, 13, '33', 'Sweet', '90', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (141, 71, 13, '33', 'Sweet', '90', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (142, 72, 13, '33', 'Sweet', '90', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (143, 73, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (144, 73, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (145, 74, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (146, 74, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (147, 75, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (148, 75, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (149, 76, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (150, 76, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (151, 77, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (152, 77, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (153, 77, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (154, 78, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (155, 78, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (156, 79, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '27.50', '2.50%', 2);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (157, 80, 11, '11', 'Fish', '50', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (158, 81, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (159, 82, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (160, 82, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (161, 83, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (162, 83, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (163, 84, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (164, 85, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (165, 85, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (166, 85, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (167, 86, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (168, 86, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (169, 87, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (170, 87, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (171, 88, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (172, 88, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (173, 89, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (174, 89, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (175, 90, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (176, 90, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (177, 90, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (178, 91, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (179, 91, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (180, 92, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (181, 92, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (182, 93, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (183, 93, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (184, 93, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (185, 94, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (186, 94, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (187, 95, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (188, 95, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (189, 96, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (190, 96, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (191, 97, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (192, 97, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (193, 97, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (194, 97, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (195, 98, 14, '66', 'Vege', '50', 1, '0.00', 1, '120.00', '120.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (196, 98, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (197, 99, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (198, 99, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (199, 100, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (200, 101, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (201, 101, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (202, 101, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (203, 102, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (204, 103, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (205, 104, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (206, 105, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (207, 105, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (208, 106, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (209, 106, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (210, 106, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (211, 106, 14, '66', 'Vege', '50', 1, '0.00', 1, '120.00', '120.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (212, 107, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (213, 107, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (214, 108, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (215, 108, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (216, 108, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (217, 108, 14, '66', 'Vege', '50', 1, '0.00', 1, '120.00', '120.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (218, 109, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (219, 109, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (220, 110, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (221, 110, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (222, 111, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (223, 111, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (224, 112, 11, '11', 'Fish', '50', 1, '0.00', 1, '767.00', '767.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (225, 112, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (226, 113, 11, '11', 'Fish', '50', 1, '0.00', 1, '767.00', '767.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (227, 113, 11, '11', 'Fish', '50', 1, '0.00', 1, '767.00', '767.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (228, 114, 11, '11', 'Fish', '50', 1, '0.00', 1, '767.00', '767.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (229, 114, 11, '11', 'Fish', '50', 1, '0.00', 1, '767.00', '767.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (230, 115, 11, '11', 'Fish', '50', 1, '0.00', 1, '767.00', '767.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (231, 115, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (232, 116, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (233, 117, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (234, 118, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (235, 119, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (236, 120, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (237, 121, 12, '22', 'Meat', '100', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (238, 122, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (239, 122, 12, '22', 'Meat', '100', 2, '24.00%', 1, '600.00', '600.00', '144.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (240, 123, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (241, 123, 12, '22', 'Meat', '100', 2, '24.00%', 1, '600.00', '600.00', '144.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (242, 124, 12, '22', 'Meat', '100', 2, '24.00%', 1, '600.00', '600.00', '144.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (243, 125, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (244, 125, 12, '22', 'Meat', '100', 2, '24.00%', 1, '600.00', '600.00', '144.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (245, 126, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (246, 126, 12, '22', 'Meat', '100', 2, '24.00%', 1, '600.00', '600.00', '144.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (247, 127, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (248, 127, 12, '22', 'Meat', '100', 2, '24.00%', 1, '600.00', '600.00', '144.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (249, 128, 11, '11', 'Fish', '50', 1, '0.00', 1, '1100.00', '1100.00', '0.00', '', '0.00', '0.00', 1);
INSERT INTO sale_items (`id`, `sale_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `serial_no`, `discount_val`, `discount`, `discount_id`) VALUES (250, 129, 13, '33', 'Sweet', '70', 2, '24.00%', 1, '1100.00', '1100.00', '264.00', '', '0.00', '0.00', 1);


#
# TABLE STRUCTURE FOR: sales
#

DROP TABLE IF EXISTS sales;

CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(55) NOT NULL,
  `warehouse_id` int(11) DEFAULT NULL,
  `biller_id` int(11) NOT NULL,
  `biller_name` varchar(55) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `internal_note` varchar(1000) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) NOT NULL,
  `invoice_type` int(11) DEFAULT NULL,
  `in_type` varchar(55) DEFAULT NULL,
  `total_tax2` decimal(25,2) DEFAULT NULL,
  `tax_rate2_id` int(11) DEFAULT NULL,
  `inv_discount` decimal(25,2) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `paid_by` varchar(55) DEFAULT 'cash',
  `count` int(11) DEFAULT NULL,
  `shipping` decimal(25,2) DEFAULT '0.00',
  `pos` tinyint(4) NOT NULL DEFAULT '0',
  `paid` decimal(25,2) DEFAULT NULL,
  `order_note` text NOT NULL,
  `cc_no` varchar(20) DEFAULT NULL,
  `cc_holder` varchar(100) DEFAULT NULL,
  `cheque_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (57, 'SL-0057', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (58, 'SL-0058', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (59, 'SL-0059', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (60, 'SL-0060', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (61, 'SL-0061', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '4525.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (62, 'SL-0062', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', 'ordernote', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (63, 'SL-0063', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '85.00', '0', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (64, 'SL-0064', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '853.00', '0', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (65, 'SL-0065', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '5365.00', '0', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (66, 'SL-0066', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '852.00', '0', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (67, 'SL-0067', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '6576.00', 'Hello JS', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (68, 'SL-0068', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', 'hi saleah', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (69, 'SL-0069', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', 'This is emergency', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (70, 'SL-0070', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (71, 'SL-0071', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', 'sadfasfas', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (72, 'SL-0072', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '1100.00', '264.00', '1336.50', NULL, NULL, '0.00', 1, '27.50', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (73, 'SL-0073', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (74, 'SL-0074', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (75, 'SL-0075', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (76, 'SL-0076', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (77, 'SL-0077', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '3300.00', '792.00', '4009.50', NULL, NULL, '0.00', 1, '82.50', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '0.00', 'this is may first purches', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (78, 'SL-0078', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '2200.00', '528.00', '2673.00', NULL, NULL, '0.00', 1, '55.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', 'this is may first purches', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (79, 'SL-0079', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '1100.00', '264.00', '1336.50', NULL, NULL, '0.00', 1, '27.50', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', 'this is may first purches', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (80, 'SL-0080', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', 'klsajlkdasjd', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (81, 'SL-0081', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-02', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (82, 'SL-0082', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-03', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '81368.00', '1132323', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (83, 'SL-0083', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-03', NULL, NULL, '2200.00', '0.00', '2200.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '81368.00', 'fdfgdsg', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (84, 'SL-0084', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-03', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (85, 'SL-0085', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-03', NULL, NULL, '3300.00', '528.00', '3828.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (86, 'SL-0086', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-03', NULL, NULL, '2200.00', '0.00', '2200.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (87, 'SL-0087', 1, 1, 'Mian Saleem', 2, 'saleah', '2015-03-03', NULL, NULL, '2200.00', '0.00', '2200.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (88, 'SL-0088', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-03', NULL, NULL, '2200.00', '528.00', '2728.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (89, 'SL-0089', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (90, 'SL-0090', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '3300.00', '528.00', '3828.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (91, 'SL-0091', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (92, 'SL-0092', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (93, 'SL-0093', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '3300.00', '528.00', '3828.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (94, 'SL-0094', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (95, 'SL-0095', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (96, 'SL-0096', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (97, 'SL-0097', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '4400.00', '528.00', '4928.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (98, 'SL-0098', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '1220.00', '264.00', '1484.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (99, 'SL-0099', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (100, 'SL-0100', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (101, 'SL-0101', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '3300.00', '528.00', '3828.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 3, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (102, 'SL-0102', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (103, 'SL-0103', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '500.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (104, 'SL-0104', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '400.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (105, 'SL-0105', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (106, 'SL-0106', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '3420.00', '528.00', '3948.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (107, 'SL-0107', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '0.00', '2200.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (108, 'SL-0108', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '3420.00', '528.00', '3948.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 4, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (109, 'SL-0109', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '528.00', '2728.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (110, 'SL-0110', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (111, 'SL-0111', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-04', NULL, NULL, '2200.00', '264.00', '2464.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (112, 'SL-0112', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1867.00', '264.00', '2131.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (113, 'SL-0113', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1534.00', '0.00', '1534.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '1500.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (114, 'SL-0114', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1534.00', '0.00', '1534.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (115, 'SL-0115', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1867.00', '264.00', '2131.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '200.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (116, 'SL-0116', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '500.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (117, 'SL-0117', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '100.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (118, 'SL-0118', 1, 1, 'Mian Saleem', 2, 'saleah', '2015-03-05', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '500.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (119, 'SL-0119', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (120, 'SL-0120', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '500.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (121, 'SL-0121', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (122, 'SL-0122', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-05', NULL, NULL, '1700.00', '144.00', '1844.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (123, 'SL-0123', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-08', NULL, NULL, '1700.00', '144.00', '1844.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (124, 'SL-0124', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-08', NULL, NULL, '600.00', '144.00', '744.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '1000.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (125, 'SL-0125', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-08', NULL, NULL, '1700.00', '144.00', '1844.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (126, 'SL-0126', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-08', NULL, NULL, '1700.00', '144.00', '1844.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (127, 'SL-0127', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-08', NULL, NULL, '1700.00', '144.00', '1844.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 2, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (128, 'SL-0128', 1, 1, 'Mian Saleem', 1, 'Test Customer', '2015-03-08', NULL, NULL, '1100.00', '0.00', '1100.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'cash', 1, '0.00', 1, '0.00', '', '', '', '');
INSERT INTO sales (`id`, `reference_no`, `warehouse_id`, `biller_id`, `biller_name`, `customer_id`, `customer_name`, `date`, `note`, `internal_note`, `inv_total`, `total_tax`, `total`, `invoice_type`, `in_type`, `total_tax2`, `tax_rate2_id`, `inv_discount`, `discount_id`, `user`, `updated_by`, `paid_by`, `count`, `shipping`, `pos`, `paid`, `order_note`, `cc_no`, `cc_holder`, `cheque_no`) VALUES (129, 'SL-0129', 1, 1, 'Mian Saleem', 2, 'saleah', '2015-03-08', NULL, NULL, '1100.00', '264.00', '1364.00', NULL, NULL, '0.00', 1, '0.00', 0, 'Owner Owner', NULL, 'Invoice', 2, '0.00', 1, '0.00', '', '', '', '');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS settings;

CREATE TABLE `settings` (
  `setting_id` int(1) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `logo2` varchar(255) NOT NULL,
  `site_name` varchar(55) NOT NULL,
  `language` varchar(20) NOT NULL,
  `default_warehouse` int(2) NOT NULL,
  `currency_prefix` varchar(3) NOT NULL,
  `default_invoice_type` int(2) NOT NULL,
  `default_tax_rate` int(2) NOT NULL,
  `rows_per_page` int(2) NOT NULL,
  `no_of_rows` int(2) NOT NULL,
  `total_rows` int(2) NOT NULL,
  `version` varchar(5) NOT NULL DEFAULT '2.3',
  `default_tax_rate2` int(11) NOT NULL DEFAULT '0',
  `dateformat` int(11) NOT NULL,
  `sales_prefix` varchar(20) NOT NULL,
  `quote_prefix` varchar(55) NOT NULL,
  `purchase_prefix` varchar(55) NOT NULL,
  `transfer_prefix` varchar(55) NOT NULL,
  `barcode_symbology` varchar(20) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `product_serial` tinyint(4) NOT NULL,
  `default_discount` int(11) NOT NULL,
  `discount_option` tinyint(4) NOT NULL,
  `discount_method` tinyint(4) NOT NULL,
  `tax1` tinyint(4) NOT NULL,
  `tax2` tinyint(4) NOT NULL,
  `restrict_sale` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_user` tinyint(4) NOT NULL DEFAULT '0',
  `restrict_calendar` tinyint(4) NOT NULL DEFAULT '0',
  `bstatesave` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO settings (`setting_id`, `logo`, `logo2`, `site_name`, `language`, `default_warehouse`, `currency_prefix`, `default_invoice_type`, `default_tax_rate`, `rows_per_page`, `no_of_rows`, `total_rows`, `version`, `default_tax_rate2`, `dateformat`, `sales_prefix`, `quote_prefix`, `purchase_prefix`, `transfer_prefix`, `barcode_symbology`, `theme`, `product_serial`, `default_discount`, `discount_option`, `discount_method`, `tax1`, `tax2`, `restrict_sale`, `restrict_user`, `restrict_calendar`, `bstatesave`) VALUES (1, 'header_logo.png', 'login_logo.png', 'Stock Manager Advance', 'english', 1, 'USD', 2, 1, 10, 9, 30, '2.3', 1, 5, 'SL', 'QU', 'PO', 'TR', 'code128', 'blue', 1, 1, 2, 1, 1, 1, 0, 0, 0, 1);


#
# TABLE STRUCTURE FOR: subcategories
#

DROP TABLE IF EXISTS subcategories;

CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `code` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: suppliers
#

DROP TABLE IF EXISTS suppliers;

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `company` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  `state` varchar(55) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `country` varchar(55) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cf1` varchar(100) DEFAULT NULL,
  `cf2` varchar(100) DEFAULT NULL,
  `cf3` varchar(100) DEFAULT NULL,
  `cf4` varchar(100) DEFAULT NULL,
  `cf5` varchar(100) DEFAULT NULL,
  `cf6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO suppliers (`id`, `name`, `company`, `address`, `city`, `state`, `postal_code`, `country`, `phone`, `email`, `cf1`, `cf2`, `cf3`, `cf4`, `cf5`, `cf6`) VALUES (1, 'Test Supplier', 'Supplier Company Name', 'Supplier Address', 'Petaling Jaya', 'Selangor', '46050', 'Malaysia', '0123456789', 'supplier@tecdiary.com', '-', '-', '-', '-', '-', '-');


#
# TABLE STRUCTURE FOR: suspended_bills
#

DROP TABLE IF EXISTS suspended_bills;

CREATE TABLE `suspended_bills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `tax1` float(25,2) DEFAULT NULL,
  `tax2` float(25,2) DEFAULT NULL,
  `discount` decimal(25,2) DEFAULT NULL,
  `inv_total` decimal(25,2) NOT NULL,
  `total` float(25,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO suspended_bills (`id`, `date`, `customer_id`, `count`, `tax1`, `tax2`, `discount`, `inv_total`, `total`) VALUES (1, '2015-03-02', 1, 2, '2400.00', '0.00', '250.00', '10000.00', '12150.00');


#
# TABLE STRUCTURE FOR: suspended_items
#

DROP TABLE IF EXISTS suspended_items;

CREATE TABLE `suspended_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suspend_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) DEFAULT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(25,2) NOT NULL,
  `gross_total` decimal(25,2) NOT NULL,
  `val_tax` decimal(25,2) DEFAULT NULL,
  `discount` varchar(55) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `discount_val` decimal(25,2) DEFAULT NULL,
  `serial_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO suspended_items (`id`, `suspend_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `discount`, `discount_id`, `discount_val`, `serial_no`) VALUES (1, 1, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '2.50%', 2, '125.00', '');
INSERT INTO suspended_items (`id`, `suspend_id`, `product_id`, `product_code`, `product_name`, `product_unit`, `tax_rate_id`, `tax`, `quantity`, `unit_price`, `gross_total`, `val_tax`, `discount`, `discount_id`, `discount_val`, `serial_no`) VALUES (2, 1, 6, '33', 'CPU', '12', 2, '24.00%', 1, '5000.00', '5000.00', '1200.00', '2.50%', 2, '125.00', '');


#
# TABLE STRUCTURE FOR: tax_rates
#

DROP TABLE IF EXISTS tax_rates;

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `rate` decimal(8,2) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (1, 'No Tax', '0.00', '2');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (2, 'VAT', '24.00', '1');
INSERT INTO tax_rates (`id`, `name`, `rate`, `type`) VALUES (3, 'GST', '6.00', '1');


#
# TABLE STRUCTURE FOR: transfer_items
#

DROP TABLE IF EXISTS transfer_items;

CREATE TABLE `transfer_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_code` varchar(55) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_unit` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `tax_rate_id` int(11) DEFAULT NULL,
  `tax` varchar(55) DEFAULT NULL,
  `tax_val` decimal(25,2) DEFAULT NULL,
  `unit_price` decimal(25,2) DEFAULT NULL,
  `gross_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: transfers
#

DROP TABLE IF EXISTS transfers;

CREATE TABLE `transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(55) NOT NULL,
  `date` date NOT NULL,
  `from_warehouse_id` int(11) NOT NULL,
  `from_warehouse_code` varchar(55) NOT NULL,
  `from_warehouse_name` varchar(55) NOT NULL,
  `to_warehouse_id` int(11) NOT NULL,
  `to_warehouse_code` varchar(55) NOT NULL,
  `to_warehouse_name` varchar(55) NOT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `total_tax` decimal(25,2) DEFAULT NULL,
  `total` decimal(25,2) DEFAULT NULL,
  `tr_total` decimal(25,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varbinary(16) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO users (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '\0\0', 'owner', '54af4ba64ec0a86f4f3e1e45159df08902ab8f40', NULL, 'owner@tecdiary.com', NULL, NULL, NULL, '6d51ca3212f297271477fb4f3ec312d68dfd1702', 1351661704, 1425818099, 1, 'Owner', 'Owner', 'Stock Manager', '0105292122');


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS users_groups;

CREATE TABLE `users_groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO users_groups (`id`, `user_id`, `group_id`) VALUES (1, 1, 1);


#
# TABLE STRUCTURE FOR: warehouses
#

DROP TABLE IF EXISTS warehouses;

CREATE TABLE `warehouses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(55) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO warehouses (`id`, `code`, `name`, `address`, `city`) VALUES (1, 'WHI', 'Warehouse 1', 'Address', 'City');


#
# TABLE STRUCTURE FOR: warehouses_products
#

DROP TABLE IF EXISTS warehouses_products;

CREATE TABLE `warehouses_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `warehouse_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (1, 1, 1, -28);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (2, 6, 1, -31);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (3, 2, 1, -5);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (4, 4, 1, -4);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (5, 5, 1, -4);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (6, 7, 1, -11);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (7, 8, 1, -1);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (8, 9, 1, -9);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (9, 10, 1, -4);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (10, 11, 1, -70);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (11, 12, 1, -61);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (12, 13, 1, -19);
INSERT INTO warehouses_products (`id`, `product_id`, `warehouse_id`, `quantity`) VALUES (13, 14, 1, -3);


